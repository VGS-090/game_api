function Admingashboard(){
    return ( 
    <div>
                <h1> Admin Dashboard Page </h1>
            </div>
    );
}
export default Admingashboard